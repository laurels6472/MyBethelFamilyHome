v45 - upload index.html and the 2 js files over the existing ones. Saved data is untouched.
